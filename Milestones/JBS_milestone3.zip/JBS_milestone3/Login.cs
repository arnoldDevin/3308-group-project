﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Text.RegularExpressions;

public class Login : MonoBehaviour {
	public GameObject password;
	public GameObject username;

	private string Password;
	private string Username;
	private string[] Lines;
	private string DecryptedPass;
	public void LoginButton(){
		bool UN = false;
		bool PW = false;

//all comments refer to the lines they are above. 
		//checks to make sure the username is not blank.
		if (Username != "") {
			//makes sure the username exists. 
			if (System.IO.File.Exists ("user_data.txt")) {
				UN = true;
				Lines = System.IO.File.ReadAllLines ("user_data.txt");
			} else {
				Debug.LogWarning ("Username does not exist");
			}
		} else {
			Debug.LogWarning ("Username field is empty");
		}
		//checks if password field is filled.
		if (Password != "") {
			if (System.IO.File.Exists("user_data.txt")) {
				//"decrypts" the password by dividing by the index of the letter in the password
				int i = 1;
				foreach (char c in Lines[2]) {
		
					i++;
					char Decrypted = (char)(c / i);
					DecryptedPass+= Decrypted.ToString();
				}
				if (DecryptedPass == Password ) {
					PW = true;
				} else {
					Debug.LogWarning ("Password is invalid");
				}
			} else {
				Debug.LogWarning ("Password is invalid");
			}
		} else {
			Debug.LogWarning ("Password field is empty");
		}
		if (UN == true && PW == true){
			//clears the username password field. 
			username.GetComponent<InputField>().text = "";
			password.GetComponent<InputField>().text = "";
			print ("Login Successful");
			Application.LoadLevel ("Level01");

		}
	}


	//allows for tab through fields. 
	void Update () {
		if (Input.GetKeyDown(KeyCode.Tab)){
			if(username.GetComponent<InputField>().isFocused){
				password.GetComponent<InputField>().Select();
			}
		}
		if (Input.GetKeyDown (KeyCode.Return)) {
			if (Username != "" && Password != "") {
				LoginButton ();
			}
		}
		//sets the contents of the login field the variable that is used. 
		Password= password.GetComponent<InputField>().text;
		Username = username.GetComponent<InputField>().text;
	}
}
