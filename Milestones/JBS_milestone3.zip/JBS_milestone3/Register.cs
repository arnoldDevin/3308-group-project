﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
//all comments refer to the lines they are above. 

	public class Register : MonoBehaviour {
		public GameObject username;
		public GameObject email;
		public GameObject password;
		public GameObject confPassword;

		private string Username;
		private string Email;
		private string Password;
		private string ConfPassword;

		private string form; // holds all the above variables
		private bool EmailValid = false;
		private string [] Characters = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
			"0","1","2","3","4","5","6","7","8","9","_","-","%","@"};


		public void RegisterButton(){
			bool UN = false;
			bool EM = false;
			bool PW = false;
			bool CPW = false;
			//checks if the username is filled in. 
			if(Username != ""){
				//checks if the username is unique
				if(!System.IO.File.Exists("user_data.txt")){
					UN = true;
				}
				else{
					Debug.LogWarning("User name already exists");
				}
			}
			else{
				Debug.LogWarning("Username Field is empty");
			}
			//checks if email is valid. 
			//calls Email validation function
			if (Email != ""){
				EmailValidation ();
				if(EmailValid){
					//verfies email contains "@" and "."
					if(Email.Contains("@")){
						if(Email.Contains(".")){
							EM = true;
						}else{
							Debug.LogWarning("Email is incorrect1");
						}
					}else{
						Debug.LogWarning("Email is incorrect2");
					}
				} else{
					Debug.LogWarning("Email is incorrect3");		
				}
			} else{
				Debug.LogWarning("Email Field is empty");		
			}
			//checks if password field is filled in. 
			if (Password != ""){
				//checks if password is si or more characters
				if(Password.Length > 5){
					PW = true; 
				} else{
					Debug.LogWarning("Password must at least six characters");
				}
			} else {
				Debug.LogWarning("Password field is empty");
			}
			//checks if password and confirm password match.
			if (ConfPassword != ""){
				if (ConfPassword == Password){
					CPW  = true; 
				}else{
					Debug.LogWarning("Passwords don't match");
				}
			} else{
				Debug.LogWarning("Confirm password field is Empty ");
			}
			// if all the above is true then the pass word is "encrypted"
			if (UN == true && EM == true && PW == true && CPW == true){
				bool Clear = true;
				int i = 1;
				foreach(char c in Password){
					if (Clear){
						Password = "";
						Clear = false;
					}
					i++;
					//password is "encrypted" character by character by multiplying each character
					//by the index postion in the password 
				char Encrypted = (char)(c*i);
					Password +=Encrypted.ToString();
				}
				//form is filled and writted to the txt file that will contian the info. 
				form = (Username+"\n"+Email+"\n"+Password+"\n");
				System.IO.File.WriteAllText("user_data.txt", form);

				//connects to mysql
				using (SqlConnection myConnection = new SqlConnection("user id=root;" + 
				"password=280732;server=localhost;" + 
				"Trusted_Connection=yes;" + 
				"database=JSUsers; " + 
				"connection timeout=30")) {
				print("test1");


				try {
					myConnection.Open ();
					print("test2");
				} catch (Exception e) {

					Console.WriteLine (e.ToString ());
				}
				//sends verbatim population command to mysql. 
				myConnection.Open ();
				print("test3");
				SqlCommand myCommand= new SqlCommand("LOAD DATA LOCAL INFILE '/Users/TGunter/Desktop/CU/FallSemester2017/cs3308/2DShooter/user_data.txt' INTO TABLE User FIELDS terminated by '\n';", myConnection);
				myCommand.ExecuteNonQuery();
			}
				//upon successful completion of registration all registration fields are cleared. 
				username.GetComponent<InputField> ().text = "";
				email.GetComponent<InputField> ().text = "";
				password.GetComponent<InputField> ().text = "";
				confPassword.GetComponent<InputField> ().text = "";
				print ("Registration complete");
			}
		}
		//update function allows the cursor to move throught the fields using the tab key 
		void Update () {
			if (Input.GetKeyDown(KeyCode.Tab)){
				if(username.GetComponent<InputField>().isFocused){
					email.GetComponent<InputField>().Select();
				}
				if(email.GetComponent<InputField>().isFocused){
					password.GetComponent<InputField>().Select();
				}
				if(password.GetComponent<InputField>().isFocused){
					confPassword.GetComponent<InputField>().Select();
				}
			}
			//allows return key to be used in place of register button. 
			if (Input.GetKeyDown (KeyCode.Return)) {
				if (Username != "" && Email != "" && Password != "" && ConfPassword != "") {
					RegisterButton ();
				}
			}
			//sets the contents of the fields to the variables the will be used to check and write. 
			Username = username.GetComponent<InputField>().text;
			Email = email.GetComponent<InputField>().text;
			Password= password.GetComponent<InputField>().text;
			ConfPassword = confPassword.GetComponent<InputField>().text;
			
		}
		//email validation function makes sure the email starts and ends with a character 

		void EmailValidation(){
			bool SW = false;
			bool EW = false;
			for (int i = 0; i < Characters.Length; i++) {
				if (Email.StartsWith (Characters [i])) {
					SW = true; 
				}
				if (Email.EndsWith (Characters [i])) {
					EW = true; 
				}
			}
			if (SW == true && EW == true) {
				EmailValid = true;
			} else {
				EmailValid = true;
			}
		}


	}

class Program
{
	static void main()
	{
		
		using (SqlConnection myConnection = new SqlConnection("user id=root;" + 
			"password=280732;server=localhost;" + 
			"Trusted_Connection=yes;" + 
			"database=JSUsers; " + 
			"connection timeout=30")) {
			Console.WriteLine("test1");


			try {
				myConnection.Open ();
				Console.WriteLine("test2");
			} catch (Exception e) {
				
				Console.WriteLine (e.ToString ());
			}

			myConnection.Open ();
			Console.WriteLine("test3");
			//SqlCommand myCommand = new SqlCommand ("DATA LOCAL INFILE /Users/TGunter/Desktop/CU/FallSemester2017/cs3308/2DShooter/user_data.txt' INTO TABLE User FIELDS terminated by '\n'");
			SqlCommand myCommand = new SqlCommand ("create table if not exists ‘store’ (\n ‘id’ int(1) not null auto_increment,\n‘name’ varchar(40) not null,\n‘qty’ int(1) not null,\n‘price’ float not null,\nprimary key (‘id’)\n) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7;\ninsert into ‘store’ (‘id’, ‘name’, ‘qty’, ‘price’)\nvalues\n (1, 'apple', 10, 1),\n(2, 'pear', 5, 2),\n(3, 'banana', 10, 1.5),\n(6, 'lemon', 100, 0.1),\n(5, 'orange', 50, 0.2);");
			myCommand.ExecuteNonQuery();
		}
	}
}
