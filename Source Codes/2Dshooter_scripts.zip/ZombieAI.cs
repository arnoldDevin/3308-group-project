﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieAI : MonoBehaviour {

	public float speed = 0.75f;
	public Transform target;

	private float initialXScale;
	// Use this for initialization
	void Start () {
		initialXScale = transform.localScale.x;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = Vector2.MoveTowards (transform.position, target.position, speed * Time.deltaTime);

		if (transform.position.x > target.position.x) {
			transform.localScale = new Vector3 (initialXScale, transform.localScale.y, transform.localScale.z);
		} else {
			transform.localScale = new Vector3 (-initialXScale, transform.localScale.y, transform.localScale.z);
		}
	}
}
